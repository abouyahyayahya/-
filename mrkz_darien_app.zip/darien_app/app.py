# -*- coding: utf-8 -*-
import os, sqlite3
from contextlib import closing
import datetime as dt
import pandas as pd
import streamlit as st
import altair as alt
from passlib.hash import bcrypt
from darien_seed import ensure_darien_seed, render_marquee

DB_PATH = os.environ.get("GRADES_DB_PATH", "grades.db")

st.set_page_config(page_title="📊 تطبيق الدرجات — مركز دارين", page_icon="📊", layout="wide")

# ---------------------------- اتصال وقاعدة ----------------------------
@st.cache_resource
def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def ensure_base_schema(conn):
    with closing(conn.cursor()) as cur:
        cur.executescript("""
        PRAGMA foreign_keys = ON;
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin','teacher')),
            password_hash TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            class_name TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE IF NOT EXISTS enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
            subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
            teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS grades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
            subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
            teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            grade_date TEXT NOT NULL,
            score REAL NOT NULL,
            note TEXT,
            note_teacher TEXT,
            note_parent TEXT,
            note_admin TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS weekly_schedule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_name TEXT NOT NULL,
            day_of_week TEXT NOT NULL,
            subject_id INTEGER NOT NULL REFERENCES subjects(id),
            teacher_id INTEGER NOT NULL REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
            subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
            teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            att_date TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('present','absent_excused','absent_unexcused')),
            note TEXT
        );
        /* المصروفات: عمودان (سداد الدراسة / سداد النقل) */
        CREATE TABLE IF NOT EXISTS fees (
            student_id INTEGER PRIMARY KEY REFERENCES students(id) ON DELETE CASCADE,
            tuition_status TEXT NOT NULL DEFAULT 'لم يسدد بعد',
            transport_status TEXT NOT NULL DEFAULT 'لم يسدد بعد'
        );
        """)
        conn.commit()

# ---------------------------- أدوات مساعدة ----------------------------
def user_by_email(conn, email):
    with closing(conn.cursor()) as cur:
        cur.execute("SELECT id, full_name, email, role, password_hash FROM users WHERE email=?", (email,))
        r = cur.fetchone()
    if r:
        return {"id": r[0], "full_name": r[1], "email": r[2], "role": r[3], "password_hash": r[4]}
    return None

def login_any(conn):
    st.subheader("تسجيل الدخول")
    email = st.text_input("البريد الإلكتروني")
    password = st.text_input("كلمة المرور", type="password")
    if st.button("دخول", type="primary"):
        u = user_by_email(conn, email.strip())
        if u and bcrypt.verify(password, u["password_hash"]):
            return {"kind": "user", **{k: u[k] for k in ("id","full_name","email","role") } }
        st.error("بيانات الدخول غير صحيحة")
    return None

def appeals_inbox(conn, scope="admin", teacher_id=None):
    st.subheader("📬 التظلمات")
    base_q = """
    SELECT a.id AS "معرف التظلم", a.grade_id AS "معرف الدرجة", s.full_name AS "الطالب",
           sub.name AS "المادة", g.score AS "الدرجة", a.reason AS "السبب", a.status AS "الحالة"
    FROM grade_appeals a
    JOIN grades g ON g.id=a.grade_id
    JOIN students s ON s.id=g.student_id
    JOIN subjects sub ON sub.id=g.subject_id
    """
    if scope == "teacher" and teacher_id:
        q = base_q + " WHERE g.teacher_id=? AND a.status='open' ORDER BY a.id DESC"
        inbox = pd.read_sql_query(q, conn, params=[int(teacher_id)])
    else:
        q = base_q + " WHERE a.status='open' ORDER BY a.id DESC"
        inbox = pd.read_sql_query(q, conn)
    st.dataframe(inbox, use_container_width=True)

# ---------------------------- لوحات حسب الدور ----------------------------
def admin_panel(conn):
    tabs = st.tabs(["👥 الطلاب","📚 المواد","🧑‍🏫 المعلّمون والتعيينات","💲 المصروفات","📈 التقارير"])
    # الطلاب
    with tabs[0]:
        c1,c2 = st.columns(2)
        with c1:
            st.markdown("**إضافة طالب**")
            n = st.text_input("اسم الطالب")
            cl = st.text_input("الصف/الفصل")
            if st.button("إضافة الطالب"):
                if n and cl:
                    conn.execute("INSERT INTO students(full_name,class_name) VALUES (?,?)", (n.strip(), cl.strip()))
                    conn.commit(); st.success("تمت إضافة الطالب"); st.rerun()
        with c2:
            df_students = pd.read_sql_query(
                "SELECT id AS 'رقم الطالب', full_name AS 'الاسم الكامل', class_name AS 'الصف' FROM students ORDER BY full_name ASC", conn)
            st.dataframe(df_students, use_container_width=True)

    # المواد
    with tabs[1]:
        c1,c2 = st.columns(2)
        with c1:
            sname = st.text_input("اسم المادة")
            if st.button("إضافة مادة"):
                if sname:
                    import sqlite3 as _sl
                    try:
                        conn.execute("INSERT INTO subjects(name) VALUES (?)",(sname.strip(),)); conn.commit(); st.success("تمت إضافة المادة"); st.rerun()
                    except _sl.IntegrityError:
                        st.error("المادة موجودة بالفعل")
        with c2:
            df_subjects = pd.read_sql_query("SELECT id AS 'المعرف', name AS 'اسم المادة' FROM subjects ORDER BY name", conn)
            st.dataframe(df_subjects, use_container_width=True)

    # المعلّمون والتعيينات (استعراض)
    with tabs[2]:
        st.info("المعلمون والتعيينات تم إنشاؤهم من البذر. استخدم هذا القسم للمراجعة.")
        q = """
        SELECT e.id AS "معرف التعيين", s.id as "رقم الطالب", s.full_name AS "الطالب", s.class_name AS "الصف",
               sub.name AS "المادة",
               (SELECT full_name FROM users WHERE id=e.teacher_id) AS "المعلم"
        FROM enrollments e
        JOIN students s ON s.id=e.student_id
        JOIN subjects sub ON sub.id=e.subject_id
        ORDER BY "الصف", "الطالب" ASC, "المادة"
        """
        st.dataframe(pd.read_sql_query(q, conn), use_container_width=True)

    # المصروفات
    with tabs[3]:
        st.markdown("**حالات سداد المصروفات** — سدد / لم يسدد بعد")
        df = pd.read_sql_query("""
            SELECT s.id AS "رقم الطالب", s.full_name AS "اسم الطالب", s.class_name AS "الصف",
                   COALESCE(f.tuition_status,'لم يسدد بعد') AS "سداد الدراسة",
                   COALESCE(f.transport_status,'لم يسدد بعد') AS "سداد النقل"
            FROM students s
            LEFT JOIN fees f ON f.student_id=s.id
            ORDER BY s.full_name
        """, conn)
        edited = st.data_editor(df, use_container_width=True, num_rows="fixed")
        if st.button("حفظ حالات السداد", type="primary"):
            with closing(conn.cursor()) as cur:
                for _, r in edited.iterrows():
                    cur.execute("SELECT 1 FROM fees WHERE student_id=?", (int(r["رقم الطالب"]),))
                    exists = cur.fetchone()
                    if exists:
                        cur.execute("UPDATE fees SET tuition_status=?, transport_status=? WHERE student_id=?",
                                    (r["سداد الدراسة"], r["سداد النقل"], int(r["رقم الطالب"])))
                    else:
                        cur.execute("INSERT INTO fees(student_id,tuition_status,transport_status) VALUES (?,?,?)",
                                    (int(r["رقم الطالب"]), r["سداد الدراسة"], r["سداد النقل"]))
                conn.commit()
            st.success("تم حفظ حالات السداد.")

    # التقارير
    with tabs[4]:
        fd = st.date_input("من تاريخ", value=None)
        td = st.date_input("إلى تاريخ", value=None)
        params=[]; where="WHERE 1=1"
        if fd: where += " AND g.grade_date >= ?"; params.append(fd.isoformat())
        if td: where += " AND g.grade_date <= ?"; params.append(td.isoformat())
        q = f"""
        SELECT g.id AS "المعرف", g.grade_date AS "التاريخ", s.id as "رقم الطالب", s.full_name AS "الطالب",
               s.class_name AS "الصف", sub.name AS "المادة",
               (SELECT full_name FROM users WHERE id=g.teacher_id) AS "المعلم",
               g.score AS "الدرجة", g.note AS "ملاحظة للطالب",
               g.note_teacher AS "ملاحظة للمعلم", g.note_parent AS "ملاحظة لولي الأمر",
               g.note_admin AS "ملاحظة للمدير"
        FROM grades g
        JOIN students s ON s.id=g.student_id
        JOIN subjects sub ON sub.id=g.subject_id
        {where}
        ORDER BY g.grade_date DESC, s.full_name ASC
        """
        st.dataframe(pd.read_sql_query(q, conn, params=params), use_container_width=True)

def teacher_daily_panel(conn, user):
    st.subheader("🗓️ إدخال الدرجات اليومية")
    teacher_classes = pd.read_sql_query("""
        SELECT DISTINCT s.class_name
        FROM enrollments e JOIN students s ON s.id = e.student_id
        WHERE e.teacher_id = ? ORDER BY s.class_name ASC
    """, conn, params=[user["id"]])
    if teacher_classes.empty:
        st.info("لم يتم تعيين أي صفوف لك بعد."); return
    selected_class = st.selectbox("اختر الصف", options=teacher_classes["class_name"])
    class_students = pd.read_sql_query("""
        SELECT s.id, s.full_name
        FROM enrollments e JOIN students s ON s.id = e.student_id
        WHERE e.teacher_id = ? AND s.class_name = ? ORDER BY s.full_name ASC
    """, conn, params=[user["id"], selected_class])
    if class_students.empty:
        st.info("لا يوجد طلاب معينون لك في هذا الصف."); return
    sid = st.selectbox("اختر الطالب", options=class_students["id"],
        format_func=lambda i: class_students.set_index('id').loc[i, 'full_name'])
    avail_subjects = pd.read_sql_query("""
        SELECT sub.id, sub.name
        FROM enrollments e JOIN subjects sub ON e.subject_id = sub.id
        WHERE e.teacher_id = ? AND e.student_id = ?
    """, conn, params=[user["id"], int(sid)])
    if avail_subjects.empty:
        st.info("لا توجد مواد معينة لهذا الطالب."); return
    subid = st.selectbox("المادة", options=avail_subjects["id"],
        format_func=lambda i: avail_subjects.set_index('id').loc[i,'name'])
    gdate = st.date_input("تاريخ اليوم", value=dt.date.today())
    score = st.number_input("الدرجة", min_value=0.0, max_value=100.0, step=0.5)
    note  = st.text_area("ملاحظة للطالب (اختياري)")
    note_p= st.text_input("ملاحظة لوليّ الأمر (اختياري)")
    note_a= st.text_input("ملاحظة للمدير (اختياري)")
    if st.button("حفظ الدرجة", type="primary"):
        conn.execute("""INSERT INTO grades(student_id,subject_id,teacher_id,grade_date,score,note,note_teacher,note_parent,note_admin)
                        VALUES (?,?,?,?,?,?,?,?,?)""" ,
                     (int(sid), int(subid), int(user["id"]), gdate.isoformat(), float(score), note, note, note_p, note_a))
        conn.commit(); st.success("تم حفظ الدرجة")

def appeals_inbox_for_teacher(conn, teacher_id):
    st.subheader("📬 التظلمات المقدّمة لدرجاتي")
    base_q = """
    SELECT a.id AS "معرف التظلم", a.grade_id AS "معرف الدرجة", s.full_name AS "الطالب",
           sub.name AS "المادة", g.score AS "الدرجة", a.reason AS "السبب", a.status AS "الحالة"
    FROM grade_appeals a 
    JOIN grades g ON g.id=a.grade_id
    JOIN students s ON s.id=g.student_id
    JOIN subjects sub ON sub.id=g.subject_id
    WHERE g.teacher_id=? AND a.status='open'
    ORDER BY a.id DESC
    """
    inbox = pd.read_sql_query(base_q, conn, params=[int(teacher_id)])
    st.dataframe(inbox, use_container_width=True)

def teacher_class_grading_panel(conn, user):
    st.subheader("📋 رصد صف كامل + التظلمات")
    teacher_classes = pd.read_sql_query("""
        SELECT DISTINCT s.class_name
        FROM enrollments e JOIN students s ON s.id = e.student_id
        WHERE e.teacher_id = ? ORDER BY s.class_name ASC
    """, conn, params=[user["id"]])
    if teacher_classes.empty:
        st.info("لم يتم تعيين أي صفوف لك بعد."); return
    class_name = st.selectbox("الصف", teacher_classes["class_name"])
    subs = pd.read_sql_query("""
        SELECT DISTINCT sub.id, sub.name
        FROM enrollments e 
        JOIN subjects sub ON sub.id=e.subject_id
        JOIN students s ON s.id=e.student_id
        WHERE e.teacher_id=? AND s.class_name=? 
        ORDER BY sub.name ASC
    """, conn, params=[user["id"], class_name])
    if subs.empty:
        st.info("لا توجد مواد معينة لك في هذا الصف."); return
    subid = st.selectbox("المادة", subs["id"], format_func=lambda i: subs.set_index('id').loc[i,'name'])
    gdate = st.date_input("تاريخ الرصد", value=dt.date.today())
    roster = pd.read_sql_query("""
        SELECT s.id AS student_id, s.full_name
        FROM enrollments e JOIN students s ON s.id=e.student_id
        WHERE e.teacher_id=? AND e.subject_id=? AND s.class_name=?
        ORDER BY s.full_name ASC
    """, conn, params=[user["id"], int(subid), class_name])
    if roster.empty: st.info("لا طلاب في هذا الصف لهذه المادة."); return
    roster_display = roster.copy()
    roster_display.rename(columns={"student_id": "رقم الطالب", "full_name": "اسم الطالب"}, inplace=True)
    roster_display["الدرجة"] = 0.0
    roster_display["الحالة"] = "present"
    roster_display["ملاحظة للطالب"] = ""
    roster_display["ملاحظة لولي الأمر"] = ""
    roster_display["ملاحظة للمدير"] = ""
    edited = st.data_editor(
        roster_display,
        column_config={
            "رقم الطالب": st.column_config.NumberColumn("رقم الطالب", disabled=True),
            "اسم الطالب": st.column_config.TextColumn("اسم الطالب", disabled=True),
            "الحالة": st.column_config.SelectboxColumn(
                "الحالة",
                options=["present","absent_excused","absent_unexcused"],
                format_func=lambda x: {"present":"حاضر","absent_excused":"غائب بعذر","absent_unexcused":"غائب بدون عذر"}.get(x,x)
            )
        },
        use_container_width=True
    )
    if st.button("حفظ رصد الصف", type="primary"):
        with closing(conn.cursor()) as cur:
            for _, r in edited.iterrows():
                cur.execute("""INSERT INTO grades(student_id,subject_id,teacher_id,grade_date,score,note,note_teacher,note_parent,note_admin)
                               VALUES (?,?,?,?,?,?,?,?,?)""", 
                            (int(r["رقم الطالب"]), int(subid), int(user["id"]), gdate.isoformat(),
                             float(r["الدرجة"]), r["ملاحظة للطالب"], r["ملاحظة للطالب"], r["ملاحظة لولي الأمر"], r["ملاحظة للمدير"]))
                cur.execute("""INSERT INTO attendance(student_id,subject_id,teacher_id,att_date,status,note)
                               VALUES (?,?,?,?,?,?)""",
                            (int(r["رقم الطالب"]), int(subid), int(user["id"]), gdate.isoformat(),
                             "present" if r["الحالة"]=="present" else r["الحالة"], r["ملاحظة للطالب"]))
            conn.commit()
        st.success("تم حفظ رصد الصف.")
    st.divider()
    appeals_inbox_for_teacher(conn, user["id"])

def teacher_panel(conn, user):
    t1, t2 = st.tabs(["🗓️ إدخال يومي", "📋 رصد صف كامل + التظلمات"])
    with t1: teacher_daily_panel(conn, user)
    with t2: teacher_class_grading_panel(conn, user)

# ---------------------------- التنفيذ ----------------------------
conn = get_conn()
ensure_base_schema(conn)
ensure_darien_seed(conn)

st.title("📊 تطبيق الدرجات — مركز دارين التعليمي")
render_marquee(conn)

if "user" not in st.session_state:
    u = login_any(conn)
    if u:
        st.session_state["user"] = u
        st.rerun()
    st.stop()

user = st.session_state["user"]

with st.sidebar:
    st.markdown(f"**مرحبًا، {user.get('full_name','')}**")
    st.caption(f"الدور: {user['role']} · 📧 {user.get('email','')}")
    if st.button("تسجيل الخروج"):
        st.session_state.clear()
        st.rerun()

if user["role"] == "admin":
    admin_panel(conn)
elif user["role"] == "teacher":
    teacher_panel(conn, user)
else:
    st.info("حاليًا تم تفعيل لوحتي المدير والمعلم في هذه الحزمة. يمكن إضافة بوابتي الطالب وولي الأمر لاحقًا.")
